<?php

namespace IXR;

/**
 * IXR异常类
 *
 * @package IXR
 */
class Exception extends \Exception
{
}
