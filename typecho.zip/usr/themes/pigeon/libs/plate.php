<?php
class Plate
{
    function short_code()
    {
    }



    //完备标题输出
	public static function EchoTitle(Widget_Archive $archive) {
		if ($archive->is('index') && Helper::options()->subTitle) {
			return Helper::options()->title . '_' . Helper::options()->subTitle;
		} else {
			$archive->archiveTitle(array(
			                    'category' => '分类 %s 下的文章',
			                    'search' => '包含关键字 %s 的文章',
			                    'tag' => '标签 %s 下的文章',
			                    'author' => '%s 发布的文章'
			                ), '', ' - ');
			return Helper::options()->title;
		}
	}

    //没有输入头像的情况下
    public static function no_avatar($Plate){
        if(Helper::options()->头像地址 == null){
            $avatar = feature::avatarHtml($Plate->author);
        }else{
            $avatar = Helper::options()->头像地址; 
        }
        return $avatar;
    }
    //没有输入头像的情况下
    public static function tz_logo($Plate){
        if(Helper::options()->头像跳转 == null){
            $logourl = Helper::options()->siteUrl;
        }else{
            $logourl = Helper::options()->头像跳转;
        }
        return $logourl;
    }
    public static function blogname_show($Plate){
        if(Helper::options()->博客名称阴影){
            return 'webname_show';
        }
    }

    public static function blogheader_show($Plate){
        if(Helper::options()->头部过度 == null){
            return 'noheader_show';
        }
    }

    //普通模式下 头部样式 识别是否有背景图
    public static function pigeon_header($Plate)
    {
        $section = null;
        $avatar = self::no_avatar($Plate);
        if (Helper::options()->头部背景 == null){
            $section .= '<div class="header_box">';
            $section .= '<div class="header_frame">';
            $section .= '<div class="header_avatar">';
            $section .= '<a href="' . self::tz_logo($Plate) . '"><img src="' . $avatar . '" alt="' . Helper::options()->title . '"></a>';
            $section .= '</div>';
            $section .= '<div class="header_info">';
            $section .= '<div class="header_info_name ' . self::blogname_show($Plate) . '"><a href="' . Helper::options()->siteUrl . '">' . Helper::options()->title . '</a></div>';
            $section .= '<div class="header_info_qm">' . Helper::options()->个性签名 . '</div>';
            $section .= '</div>';
            $section .= '</div>';
            $section .= '</div>';
        }else{
            $section .= '<div class="header_bg">';
            $section .= '<div class="header_bg_img"><img src="' . Helper::options()->头部背景 . '"></div>';
            $section .= '<div class="header_bg_filter ' . self::blogheader_show($Plate) . '">';
            $section .= '<div class="header_frame">';
            $section .= '<div class="header_avatar"><a href="' . self::tz_logo($Plate) . '"><img src="' . $avatar . '" alt="' . Helper::options()->title . '"></a></div>';
            $section .= '<div class="header_info">';
            $section .= '<div class="header_info_name ' . self::blogname_show($Plate) . '"><a href="' . Helper::options()->siteUrl . '">' . Helper::options()->title . '</a></div>';
            $section .= '<div class="header_info_qm">' . Helper::options()->个性签名 . '</div>';
            $section .= '</div>';
            $section .= '</div>';
            $section .= '</div>';
            $section .= '</div>';
        }
        return $section;
    }

    //风格先择
    public static function index_card($Plate){
        if(Helper::options()->主题风格 == "卡片风格"){
            return 'index_card';
        }
    }

    //幻灯片卡片
    public static function slide_cards($Plate){
        if(Helper::options()->主题风格 == "卡片风格"){
            return 'slide_card';
        }
    }
    //分类卡片
    public static function communal_card($Plate){
        if(Helper::options()->主题风格 == "卡片风格"){
            return 'communal_card';
        }
    }

    
    //主题皮肤
    public static function theme_skin($Plate){
        if(Helper::options()->主题皮肤 == "默认皮肤"){
            return 'normal';
        }elseif(Helper::options()->主题皮肤 == "新拟物皮肤"){
            return 'obje';
        }
    }

    //图片位置
    public static function list_img($Plate){
        if(Helper::options()->列表图片位置 == "图片在左"){
            return 'index_box_left';
        }elseif(Helper::options()->列表图片位置 == "图片在右"){
            return 'index_box_right';
        }elseif(Helper::options()->列表图片位置 == "图片交叉"){
            return 'index_box_over';
        }
    }
    public static function Categorytitle(Widget_Archive $Plate)
    {
            $Plate->archiveTitle(array(
                'category' => _t('%s'),
                'search' => _t('%s'),
                'tag' => _t('%s'),
            ), '', '');
    }
    //已发布文章数量
    public static function getPostNum()
    {
        $db = Typecho_Db::get();
        return $db->fetchObject($db->select(array('COUNT(cid)' => 'num'))
            ->from('table.contents')
            ->where('table.contents.type = ?', 'post')
            ->where('table.contents.status = ?', 'publish'))->num;
    }

    //归档
    public static function archivehead($Plate)
    {
        $section = null;
        $PostNum = self::getPostNum($Plate);
        if (Helper::options()->归档背景图 == "null"){
            $section .= '<div class="file_box">';
            $section .= '<h1 class="file_box_title">文章归档</h1>';
            $section .= '<div class="file_box_qm">TOTALY '. $PostNum .' POSTS</div>';
            $section .= '</div>';
        }else{
            $section .= '<div class="archive_color">';
            $section .= '<div class="archive_img"><img src="' . Helper::options()->归档背景图 . '"></div>';
            $section .= '<div class="archive_basic"></div>';
            $section .= '<div class="archive_detail">';
            $section .= '<div class="archive_name">文章归档</div>';
            $section .= '<div class="archive_number">TOTALY '. $PostNum .' POSTS</div>';
            $section .= '</div>';
            $section .= '</div>';
        }
        
        return $section;
    }


    //自定义主色
    public static function style_cust($Plate){
        if(Helper::options()->自定主色){
            return ':root{--dark-green:'.Helper::options()->自定主色.'}';
        }
    }

    public static function img_body($Plate){
        if(Helper::options()->网站背景图片){
            return 'body{background: url("'.Helper::options()->网站背景图片.'") center center no-repeat no-repeat fixed #6A6B6F;background-size: cover;}';
        }
    }

    public static function color_body($Plate){
        if(Helper::options()->背景颜色){
            return '.normal{background-color:'.Helper::options()->背景颜色.'}';
        }
    }

    public static function archive_zd($Plate){
        if(Helper::options()->归档折叠){
            return 'archives_btn';
        }
    }

    public static function archive_zdul($Plate){
        if(Helper::options()->归档折叠){
            return 'archives_open';
        }
    }


    public static function headergd($Plate){
        if(Helper::options()->头部高度){
            return '#header .header_bg_img {height: '.Helper::options()->头部高度.';}';
        }
    }
    public static function headertx($Plate){
        if(Helper::options()->头部高度){
            return '#header .header_avatar{height: '.Helper::options()->头像高度.';width: '.Helper::options()->头像高度.';}';
        }
    }


    public static function lanjiazai($Plate){
        if(Helper::options()->lazdy){
            return 'class="lazy" data-';
        }
    }
    
    public static function lanjiazaipost($Plate){
        if(Helper::options()->lazdy){
            return 'class="lazy poster-zoom" data-';
        }
    }

    public static function webkuan($Plate){
        if(Helper::options()->web_with){
            return '.content{max-width:'.Helper::options()->web_with.'px}';
        }
    }

    public static function navbar_gs($Plate){
        if(Helper::options()->导航跟随){
            return 'xiding';
        }
    }

}
//自定义cdn
if(Helper::options()->optionalcdn == "bendi"){
    @define('customcdn',  '' . Helper::options()->themeUrl . '/assets/');
    @define('qnprogress',  '' . Helper::options()->themeUrl . '/assets/css/nprogress.min.css');
    @define('fancyboxcsscdn',  '' . Helper::options()->themeUrl . '/assets/css/jquery.fancybox.min.css');
    @define('APlayercsscdn',  '' . Helper::options()->themeUrl . '/assets/css/APlayer.min.css');
    @define('swipercsscdn',  '' . Helper::options()->themeUrl . '/assets/css/swiper-bundle.min.css');
    @define('jqueryjs',  '' . Helper::options()->themeUrl . '/assets/js/jquery.min.js');
    @define('tocbotjscdn',  '' . Helper::options()->themeUrl . '/assets/js/tocbot.min.js');
    @define('sidebarjscdn',  '' . Helper::options()->themeUrl . '/assets/js/sticky-sidebar.min.js');
    @define('pjaxjs',  '' . Helper::options()->themeUrl . '/assets/js/jquery.pjax.min.js');
    @define('nprogressjs',  '' . Helper::options()->themeUrl . '/assets/js/nprogress.min.js');
    @define('prismjs',  '' . Helper::options()->themeUrl . '/assets/js/prism.min.js');
    @define('aplayerjs',  '' . Helper::options()->themeUrl . '/assets/js/APlayer.min.js');
    @define('swiperjs',  '' . Helper::options()->themeUrl . '/assets/js/swiper-bundle.min.js');
    @define('fancyboxjs',  '' . Helper::options()->themeUrl . '/assets/js/jquery.fancybox.min.js');
}elseif(Helper::options()->optionalcdn == "qiniu"){
    @define('customcdn',  '' . Helper::options()->themeUrl . '/assets/');
    @define('qnprogress', 'https://cdn.staticfile.org/nprogress/0.2.0/nprogress.min.css');
    @define('fancyboxcsscdn', 'https://cdn.staticfile.org/fancybox/3.5.7/jquery.fancybox.min.css');
    @define('APlayercsscdn', 'https://cdn.staticfile.org/aplayer/1.9.1/APlayer.min.css');
    @define('swipercsscdn', 'https://cdn.staticfile.org/Swiper/6.8.1/swiper-bundle.min.css');
    @define('jqueryjs', 'https://cdn.staticfile.org/jquery/3.6.0/jquery.min.js');
    @define('tocbotjscdn', 'https://cdn.staticfile.org/tocbot/4.18.0/tocbot.min.js');
    @define('sidebarjscdn', 'https://cdn.staticfile.org/sticky-sidebar/3.3.1/sticky-sidebar.min.js');
    @define('pjaxjs', 'https://cdn.staticfile.org/jquery.pjax/2.0.1/jquery.pjax.min.js');
    @define('nprogressjs', 'https://cdn.staticfile.org/nprogress/0.2.0/nprogress.min.js');
    @define('fancyboxjs', 'https://cdn.staticfile.org/fancybox/3.5.7/jquery.fancybox.min.js');
    @define('aplayerjs', 'https://cdn.staticfile.org/aplayer/1.9.1/APlayer.min.js');
    @define('swiperjs', 'https://cdn.staticfile.org/Swiper/6.8.1/swiper-bundle.min.js');
}elseif(Helper::options()->optionalcdn == "toutiao"){
    @define('customcdn',  '' . Helper::options()->themeUrl . '/assets/');
    @define('qnprogress', 'https://lf3-cdn-tos.bytecdntp.com/cdn/expire-1-M/nprogress/0.2.0/nprogress.min.css');
    @define('fancyboxcsscdn', 'https://lf6-cdn-tos.bytecdntp.com/cdn/expire-1-M/fancybox/3.5.7/jquery.fancybox.min.css');
    @define('APlayercsscdn', 'https://lf3-cdn-tos.bytecdntp.com/cdn/expire-1-M/aplayer/1.9.1/APlayer.min.css');
    @define('swipercsscdn', 'https://lf26-cdn-tos.bytecdntp.com/cdn/expire-1-M/Swiper/6.8.1/swiper-bundle.min.css');
    @define('jqueryjs', 'https://lf6-cdn-tos.bytecdntp.com/cdn/expire-1-M/jquery/3.5.1/jquery.min.js');
    @define('tocbotjscdn', 'https://lf6-cdn-tos.bytecdntp.com/cdn/expire-1-M/tocbot/4.12.2/tocbot.min.js');
    @define('sidebarjscdn', 'https://lf26-cdn-tos.bytecdntp.com/cdn/expire-1-M/sticky-sidebar/3.3.1/sticky-sidebar.min.js');
    @define('pjaxjs', 'https://lf3-cdn-tos.bytecdntp.com/cdn/expire-1-M/jquery.pjax/2.0.1/jquery.pjax.min.js');
    @define('nprogressjs', 'https://lf6-cdn-tos.bytecdntp.com/cdn/expire-1-M/nprogress/0.2.0/nprogress.min.js');
    @define('fancyboxjs', 'https://lf26-cdn-tos.bytecdntp.com/cdn/expire-1-M/fancybox/3.5.7/jquery.fancybox.min.js');
    @define('aplayerjs', 'https://lf6-cdn-tos.bytecdntp.com/cdn/expire-1-M/aplayer/1.9.1/APlayer.min.js');
    @define('swiperjs', 'https://lf9-cdn-tos.bytecdntp.com/cdn/expire-1-M/Swiper/6.8.1/swiper-bundle.min.js');
}elseif(Helper::options()->optionalcdn == "zdycdn"){
    @define('customcdn','' . Helper::options()->cdnurl . '/assets/');
    @define('customcdnbq','' . Helper::options()->cdnurl .'');
    @define('qnprogress',  '' . Helper::options()->cdnurl . '/assets/css/nprogress.min.css');
    @define('fancyboxcsscdn',  '' . Helper::options()->cdnurl . '/assets/css/jquery.fancybox.min.css');
    @define('APlayercsscdn',  '' . Helper::options()->cdnurl . '/assets/css/APlayer.min.css');
    @define('swipercsscdn',  '' . Helper::options()->cdnurl . '/assets/css/swiper-bundle.min.css');
    @define('jqueryjs',  '' . Helper::options()->cdnurl . '/assets/js//jquery.min.js');
    @define('tocbotjscdn',  '' . Helper::options()->cdnurl . '/assets/js/tocbot.min.js');
    @define('sidebarjscdn',  '' . Helper::options()->cdnurl . '/assets/js/sticky-sidebar.min.js');
    @define('pjaxjs',  '' . Helper::options()->cdnurl . '/assets/js/jquery.pjax.min.js');
    @define('nprogressjs',  '' . Helper::options()->cdnurl . '/assets/js/nprogress.min.js');
    @define('aplayerjs',  '' . Helper::options()->cdnurl . '/assets/js/APlayer.min.js');
    @define('swiperjs',  '' . Helper::options()->cdnurl . '/assets/js/swiper-bundle.min.js');
    @define('fancyboxjs',  '' . Helper::options()->cdnurl . '/assets/js/jquery.fancybox.min.js');
}
function themeFields($layout) {
    $Pictype= new Typecho_Widget_Helper_Form_Element_Select('Pictype',array(
        '0' => _t('文字'),
        '1' => _t('多图'),
        '2' => _t('一言')),
        '0',_t('文章类型'),_t("选择文章类型，模板设置在数据列表显示不同的样式，比如大图和三图并列的文章列表"));
    $layout->addItem($Pictype);

    $banner = new Typecho_Widget_Helper_Form_Element_Text('banner', NULL, NULL,_t('文章头图'), _t('输入一个图片 url，作为缩略图显示在文章列表，没有则不显示'));
    $layout->addItem($banner);

    $articleCopyright = new Typecho_Widget_Helper_Form_Element_Select('articleCopyright', array(
        'show' => '显示',
        'hide' => '不显示'
    ), 'show', _t('文章目录'), _t('开启后会显示文章目录'));
    $layout->addItem($articleCopyright); 
    Plate::short_code();

    $postjj = new Typecho_Widget_Helper_Form_Element_Textarea('postjj', NULL, NULL,_t('文章描述'), _t('此处为搜索引擎抓取部分，如果不填写则默认抓取文章前120个字'));
    $layout->addItem($postjj);

    $postgjc = new Typecho_Widget_Helper_Form_Element_Text('postgjc', NULL, NULL,_t('文章关键词'), _t('多个关键词用英文下逗号隔开，为所搜引擎抓取，如果不填写则默认为标签'));
    $layout->addItem($postgjc);
}
