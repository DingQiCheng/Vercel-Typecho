<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php
/**
 * 时光机
 *
 * @package custom
 *
 */$this->need('common/header.php');
?>
            <div class="content_top">
            <article class="public">
            <?php $this->need('common/say.php'); ?>
            </article>
            </div>

<?php $this->need('common/footer.php'); ?>