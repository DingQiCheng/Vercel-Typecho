<?php
$this->widget('Widget_Metas_Category_List')->to($categorys);
$this->widget('Widget_Contents_Page_List')->to($pages);
?> 
<!DOCTYPE html>
<html>
    <head>
        <meta charset=utf-8>
        <meta content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=0" name=viewport>
        <?php if($this->options->iconurl): ?>
        <link rel="icon" href="<?php $this->options->iconurl(); ?>" />
        <?php endif; ?>
        <title><?= Plate::EchoTitle($this); ?></title>
        <meta itemprop="name" content="<?= Plate::EchoTitle($this); ?>"/>
        <?php if($this->is('index') || $this->is('archive')): ?>
        <meta itemprop="image" content="<?php $this->options->iconurl(); ?>" />
        <?php endif; ?>
        <?php if($this->is('post') || $this->is('page')): ?>
        <?php if($this->fields->banner){ ?>
        <meta itemprop="image" content="<?php $this->fields->banner(); ?>" />
        <?php } else { ?>
        <meta itemprop="image" content="<?php $this->options->iconurl(); ?>" />
        <?php } ?>
        <?php endif; ?>
        <?php if($this->is('index') || $this->is('archive')): ?>
        <meta name="description" content="<?php $this->options->description() ?>" />
        <meta name="description" itemprop="description" content="<?php $this->options->description() ?>" />
        <?php endif; ?>
        <?php if($this->is('post') || $this->is('page')): ?>
        <?php if($this->fields->postjj){ ?>
        <meta name="description" content="<?php $this->fields->postjj(); ?>" />
        <meta name="description" itemprop="description" content="<?php $this->fields->postjj(); ?>" />
        <?php } else { ?>
        <meta name="description" content="<?php echo feature::excerpt($this->content,120); ?>" />
        <meta name="description" itemprop="description" content="<?php echo feature::excerpt($this->content,120); ?>" />
        <?php } ?>
        <?php endif; ?>

        <?php if($this->is('index') || $this->is('archive')): ?>
        <meta name="keywords" content="<?php $this->options->keywords() ?>" />
        <?php endif; ?>
        <?php if($this->is('post') || $this->is('page')): ?>
        <?php if($this->fields->postgjc){ ?>
        <meta name="keywords" content="<?php $this->fields->postgjc(); ?>" />
        <?php } else { ?>
        <meta name="keywords" content="<?php $this->tags(',', false); ?>" />
        <?php } ?>
        <?php endif; ?>

        <meta name="author" content="<?php $this->author(); ?>" />
        <meta property="og:title" content="<?= Plate::EchoTitle($this); ?>" /> 
        <?php if($this->is('index') || $this->is('archive')): ?>
        <meta property="og:description" content="<?php $this->options->description() ?>" />
        <?php endif; ?>
        <?php if($this->is('post') || $this->is('page')): ?>
        <?php if($this->fields->postjj){ ?>
        <meta name="og:description" content="<?php $this->fields->postjj(); ?>" />
        <?php } else { ?>
        <meta name="dog:description" content="<?php echo feature::excerpt($this->content,120); ?>" />
        <?php } ?>
        <?php endif; ?>
        <meta property="og:site_name" content="<?php Helper::options()->title(); ?>" />
        <meta property="og:type" content="<?php if($this->is('post') || $this->is('page')) echo 'article'; else echo 'website'; ?>" />
        <meta property="og:url" content="<?php $this->permalink(); ?>" />
        <?php if($this->is('index') || $this->is('archive')): ?>
            <meta property="og:image" content="<?php $this->options->iconurl(); ?>" />  
        <?php endif; ?>
        <?php if($this->is('post') || $this->is('page')): ?>
        <?php if($this->fields->banner){ ?>
        <meta property="og:image" content="<?php $this->fields->banner(); ?>" />
        <?php } else { ?>
        <meta property="og:image" content="<?php $this->options->iconurl(); ?>" />   
        <?php } ?>
        <?php endif; ?>
        <meta property="article:published_time" content="<?php echo date('c', $this->created); ?>" />
        <meta property="article:modified_time" content="<?php echo date('c', $this->modified); ?>" />
        <meta name="twitter:title" content="<?= Plate::EchoTitle($this); ?>" />
        <?php if($this->is('index') || $this->is('archive')): ?>
        <meta name="twitter:description" content="<?php $this->options->description() ?>" />
        <?php endif; ?>
        <?php if($this->is('post') || $this->is('page')): ?>
        <?php if($this->fields->postjj){ ?>
        <meta name="twitter:description" content="<?php $this->fields->postjj(); ?>" />
        <?php } else { ?>
        <meta name="twitter:description" content="<?php echo feature::excerpt($this->content,120); ?>" />
        <?php } ?>
        <?php endif; ?>
        <meta name="twitter:card" content="summary" />
        <?php if($this->is('index') || $this->is('archive')): ?>
            <meta name="twitter:image" content="<?php $this->options->iconurl(); ?>" /> 
        <?php endif; ?>
        <?php if($this->is('post') || $this->is('page')): ?>
        <?php if($this->fields->banner){ ?>
        <meta name="twitter:image" content="<?php $this->fields->banner(); ?>" />
        <?php } else { ?>
            <meta name="twitter:image" content="<?php $this->options->iconurl(); ?>" />
        <?php } ?>
        <?php endif; ?>
        <link rel=stylesheet href="<?= customcdn . 'css/style.css?v4.1.1'; ?>">
        <link rel=stylesheet href="<?= customcdn . '/message.min.css'; ?>">
        <link rel=stylesheet href="https://at.alicdn.com/t/font_2775295_ju4gvxginvn.css">
        <link rel="stylesheet" type="text/css" href="<?= qnprogress ?>">
        <link rel="stylesheet" href="<?= fancyboxcsscdn ?>" />
        <link rel="stylesheet" href="<?= APlayercsscdn ?>">
        <link rel="stylesheet" href="<?= customcdn . 'css/mp.min.css'; ?>" />
        <?php if ($this->options->swiper):?>
        <link rel="stylesheet" href="<?= swipercsscdn ?>" />
        <?php endif; ?>
        
        <script type="text/javascript" src="<?= jqueryjs ?>"></script>
        <script type="text/javascript" src="<?= customcdn . 'js/OwO.js'; ?>"></script>
        <script src="<?= tocbotjscdn ?>"></script>
        <script src="<?= sidebarjscdn ?>"></script>
    <?php $this->header('keywords=&description=','commentReply='); ?>
<style>
    <?= Plate::color_body($this) ?>
       <?= Plate::style_cust($this) ?>
       <?= Plate::img_body($this) ?>
       <?= Plate::headergd($this) ?>
       <?= Plate::headertx($this) ?>
       <?= Plate::webkuan($this) ?>
       <?php if ($this->options->googlefonts):?>
       @font-face{
           font-family:'hm';
           src : url('<?= customcdn . 'fonts/hm.woff2'; ?>')format("truetype");
        }
        <?php endif; ?>
    <?php $this->options->自定义CSS(); ?>
</style>

    </head>
    
    <body class="<?= Plate::theme_skin($this) ?> match <?php if ($this->options->夜间开关):?><?php echo($_COOKIE['night'] == '1' ? 'dark' : ''); ?><?php endif; ?>">
        <div class="content">
            <header id="header" class="match_bg">
            <?= Plate::pigeon_header($this) ?>
            </header>
            <div id="pjax">
            <div id="headers" class="match_bg <?= Plate::navbar_gs($this) ?>">
            <div class="navbar">
                    <div class="meun_list">
                        <ul class="meun_ul">
                            <li class="meun_li"><a href="<?php $this->options->siteUrl(); ?>">首页</a></li>
                            <?= feature::OrderSet($pages, $categorys) ?>
                        </ul>
                    </div>
                    <div class="search_btn" onclick="search_show()" ><i id="sou_block" class="iconfont icon-sousuo"></i><i id="sou_none" class="iconfont icon-guanbi"></i></div>
                </div>

                <div id="search_bar">
                    <form method="post" action="">
                        <div id="search" class="search_frame"><input type="text" name="s" class="text search_input" size="32" placeholder="请输入搜索内容..."> <input type="submit" class="submit" value="Search"></div>
                    </form>
            </div>
            </div>

            
<script>
    Config = {
        homeUrl: '<?php $this->options->siteUrl(); ?>',
        themeUrl: '<?=feature::ThemeUrl()?>',
        cdnUrl: '<?php if($this->options->optionalcdn == "zdycdn"){ ?><?= customcdn ?><?php } else {?><?=feature::ThemeUrl()?><?php } ?>',
        Pjax: '<?php if ($this->options->pjax_switch):?>true<?php else: ?>off<?php endif; ?>',
        swiper:'<?php if ($this->options->swiper):?>true<?php else: ?>off<?php endif; ?>',
        post_id:'<?php if ($this->is('post')){$this->cid();}else{echo '0';} ?>',
        ajax_url:'<?php Typecho_Widget::widget('Widget_Security')->to($security); $security->index('?'); ?>',
        musicId: '<?=feature::ParseMusic($this->options->musicurl)['id']?>',
        musicMedia: '<?=feature::ParseMusic($this->options->musicurl)['media']?>',
    };
</script>