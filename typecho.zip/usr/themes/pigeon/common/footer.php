</div>
<footer id="footer" class="match_bg">
    <div class="links">
              <?php if ($this->options->twitter): ?>
              <a href="<?php $this->options->twitter(); ?>" title="twitter" target="_blank"><i class="iconfont icon-ttww"></i></a>
              <?php endif; ?>
              <?php if ($this->options->weibo): ?>
              <a href="<?php $this->options->weibo(); ?>" title="微博" target="_blank"><i class="iconfont icon-weibo"></i></a>
              <?php endif; ?>
              <?php if ($this->options->github): ?>
              <a href="<?php $this->options->github(); ?>" title="Github" target="_blank"><i class="iconfont icon-github"></i></a>
              <?php endif; ?>
              <?php if ($this->options->telegram): ?>
              <a href="<?php $this->options->telegram(); ?>" title="telegram" target="_blank"><i class="iconfont icon-telegram"></i></a>
              <?php endif; ?>
              <?php if ($this->options->mastodon): ?>
              <a rel="me" href="<?php $this->options->mastodon(); ?>" title="长毛象" target="_blank"><i class="iconfont icon-mastodon"></i></a>
              <?php endif; ?>
              <?php if ($this->options->bilibili): ?>
              <a href="<?php $this->options->bilibili(); ?>" title="哔哩哔哩" target="_blank"><i class="iconfont icon-bilibili"></i></a>
              <?php endif; ?>
              <?php if ($this->options->rss): ?>
              <a href="<?php $this->options->rss(); ?>" title="Rss" target="_blank"><i class="iconfont icon-rss"></i></a>
              <?php endif; ?>
              <?php if ($this->options->douban): ?>
              <a href="<?php $this->options->douban(); ?>" title="豆瓣" target="_blank"><i class="iconfont icon-douban"></i></a>
              <?php endif; ?>
              <?php if ($this->options->zhihu): ?>
              <a href="<?php $this->options->zhihu(); ?>" title="知乎" target="_blank"><i class="iconfont icon-zhihu"></i></a>
              <?php endif; ?>
    </div>

    <div class="synopsis"><?php $this->options->网站版权(); ?></div>

    <span><?php if($this->options->网站备案): ?><a href="https://beian.miit.gov.cn/" target="_blank" rel="noopener"><?php $this->options->网站备案(); ?>.<?php endif; ?></a>Theme <a href="http://sire.cc/" title="Sire" target="_blank">Sire</a></span></p>
    博客已稳定运行：<SPAN id=span_dt_dt style="color: #2F889A;"></SPAN> <SCRIPT language=javascript>function show_date_time(){
window.setTimeout("show_date_time()", 1000);
BirthDay=new Date("8/21/2017 23:32:13");
today=new Date();
timeold=(today.getTime()-BirthDay.getTime());
sectimeold=timeold/1000
secondsold=Math.floor(sectimeold);
msPerDay=24*60*60*1000
e_daysold=timeold/msPerDay
daysold=Math.floor(e_daysold);
e_hrsold=(e_daysold-daysold)*24;
hrsold=Math.floor(e_hrsold);
e_minsold=(e_hrsold-hrsold)*60;
minsold=Math.floor((e_hrsold-hrsold)*60);
seconds=Math.floor((e_minsold-minsold)*60);
span_dt_dt.innerHTML='<font style=color:#C40000>'+daysold+'</font> 天 <font style=color:#C40000>'+hrsold+'</font> 时 <font style=color:#C40000>'+minsold+'</font> 分 <font style=color:#C40000>'+seconds+'</font> 秒';
}
show_date_time();</script>加载耗时：<font style=color:#C40000><?php echo timer_stop();?>
    
    <div style="text-align:center;"><font color="#FF6666">富强</font>丨<font color="#336666">民主</font>丨<font color="#009966">文明</font>丨<font color="#FF0000">和谐</font>丨<font color="#6666CC">自由</font>丨<font color="#33CC33">平等</font>丨<font color="#6666cc">公正</font>丨<font color="#FF6666">法制丨<font color="#336666">爱国</font>丨<font color="#009966">敬业</font>丨<font color="#FF9933">诚信</font>丨<font color="#6666CC">友善</font></div>
</footer>
<div class="tools">
    <?php if($this->is('post')): ?>
    <?php if($this->user->hasLogin()):?>
    <div class="tools_edit"><a target="_blank" href="<?php $this->options->adminUrl(); ?>write-post.php?cid=<?php echo $this->cid;?>"><i class="iconfont icon-pinglun1"></i></a></div>
    <?php endif;?>
    <?php endif; ?>
    <?php if ($this->options->夜间开关):?>
    <div class="tools_night"><a href="javascript:switchNightMode()"><i class="iconfont icon-taiyang"></i></a></div>
    <?php endif; ?>
    <div class="tools_top" id="top_to" ><i class="iconfont icon-top1"></i></div>
</div>
<?php if ($this->options->music_play):?>
    <div style="position: fixed;top:50px;right:2%; z-index:9999;"><div id="CTPlayer" class="relative flex items-center"></div></div>
<?php endif; ?>
<script type="text/javascript" src="<?= pjaxjs ?>"></script>
<script src="<?= nprogressjs ?>"></script>
<script src="<?= customcdn . 'js/prism.min.js'; ?>"></script>
<script type="text/javascript" src="<?= customcdn . 'js/jquery.lazyload.min.js'; ?>"></script>
<script src="<?= fancyboxjs ?>"></script>
<script src="<?= aplayerjs ?>"></script>
<?php if ($this->options->music_play):?>
<script type="text/javascript" src="<?= customcdn . 'js/Player.js'; ?>"></script>
<?php endif; ?>
<script type="text/javascript" src="<?= customcdn . 'js/message.min.js'; ?>"></script>
<?php if ($this->options->swiper):?>
<script type="text/javascript" src="<?= swiperjs ?>"></script>
<?php endif; ?>
<script type="text/javascript" src="<?= customcdn . 'js/pigeon.js'; ?>"></script>
<!--浏览器动态标题开始-->
<script>
 var OriginTitle = document.title;
 var titleTime;
 document.addEventListener('visibilitychange', function () {
     if (document.hidden) {
         $('[rel="icon"]').attr('href', "//file.kaygb.top/static_image/tx.png");
         document.title = 'ヽ(●-`Д´-)ノ我藏好了哦！';
         clearTimeout(titleTime);
     }
     else {
         $('[rel="icon"]').attr('href', "//file.kaygb.top/static_image/tx.png");
         document.title = 'ヾ(Ő∀Ő3)ノ被你发现啦~！' + OriginTitle;
         titleTime = setTimeout(function () {
             document.title = OriginTitle;
         }, 2000);
     }
 });
</script>
<!--浏览器动态标题结束-->

</div>
<?php $this->footer(); ?>

<script type="text/javascript">
	$(document).on('pjax:complete', function() {
        if (typeof Prism !== 'undefined') {
        var pres = document.getElementsByTagName('pre'); for (var i = 0; i < pres.length; i++) { if (pres[i].getElementsByTagName('code').length > 0) pres[i].className  = 'line-numbers'; }
        Prism.highlightAll(true,null);
    }
        <?php $this->options->hdhs(); ?>
});

<?php if ($this->options->夜间开关):?>


    function switchNightMode() {
    var night = document.cookie.replace(/(?:(?:^|.*;\s*)night\s*\=\s*([^;]*).*$)|^.*$/, "$1") || "0";
    if (night == "0") {
        document.body.classList.add("dark");
        document.cookie = "night=1;path=/";
        console.log("夜间模式开启")
    } else {
        document.body.classList.remove("dark");
        document.cookie = "night=0;path=/";
        console.log("夜间模式关闭")
    }
} (function() {
    if (document.cookie.replace(/(?:(?:^|.*;\s*)night\s*\=\s*([^;]*).*$)|^.*$/, "$1") === "") {
        if (new Date().getHours() > <?php $this->options->开夜间模式(); ?> || new Date().getHours() < <?php $this->options->关闭夜间模式(); ?>) {
            document.body.classList.add("dark");
            document.cookie = "night=1;path=/";
            console.log("夜间模式开启")
        } else {
            document.body.classList.remove("dark");
            document.cookie = "night=0;path=/";
            console.log("夜间模式关闭")
        }
    } else {
        var night = document.cookie.replace(/(?:(?:^|.*;\s*)night\s*\=\s*([^;]*).*$)|^.*$/, "$1") || "0";
        if (night == "0") {
            document.body.classList.remove("dark")
        } else {
            if (night == "1") {
                document.body.classList.add("dark")
            }
        }
    }
})();
<?php endif; ?>
</script>
<?php $this->options->footerjs(); ?>
</body>
</html>

<?php if ($this->options->Html压缩输出) : $html_source = ob_get_contents();
    ob_clean();
    print feature::compressHtml($html_source);
    ob_end_flush();
endif; ?>